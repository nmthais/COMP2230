Name: Minh Thai Nguyen
ID: c3440776